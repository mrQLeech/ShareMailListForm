/// <references path="../_refs.ts" />
//# sourceMappingURL=IEMailItem.js.map