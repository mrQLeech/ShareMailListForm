/// <reference path="../_refs.ts" />

module emailEditorMod{
    export interface IEMailItem{
        getMail ():string;
        isValid(): boolean;
    }
}
