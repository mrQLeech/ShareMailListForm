/// <reference path='../_all.ts' />
//# sourceMappingURL=ITodoScope.js.map