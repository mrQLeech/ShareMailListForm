/// <reference path='../_all.ts' />
//# sourceMappingURL=ITodoStorage.js.map